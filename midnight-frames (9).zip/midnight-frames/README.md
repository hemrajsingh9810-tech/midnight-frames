# midnight frames 🌙

A responsive, dark-aesthetic meme website built with plain HTML, CSS, and JavaScript.

## Features
- Responsive mobile-first layout
- Search captions and filter by vibe
- Like memes (saved in the current browser)
- Copy meme captions
- Random meme surprise button
- Add custom caption/emoji memes (saved locally in the current browser)
- No build tools or dependencies required

## Run locally
Open `index.html` in your browser.

## Publish with GitHub Pages
1. Create a **public** repository on GitHub named `midnight-frames`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for GitHub Pages to finish publishing. Your site will appear at:
   `https://YOUR-GITHUB-USERNAME.github.io/midnight-frames/`

## Important notes
This is a front-end demo. Likes and custom submissions are stored only in the visitor's own browser. They are not shared between visitors. Public meme uploads, accounts, comments, and moderation require a backend/database.
